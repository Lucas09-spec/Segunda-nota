package com.Proyecto.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Proyecto.Model.Proyecto;
import com.Proyecto.Repository.ProyectoRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional

public class ProyectoService {
    @Autowired
    private ProyectoRepository proyectoRepository;

    public List<Proyecto> getProyectos(){
        return proyectoRepository.findAll();
    }

    public Proyecto gProyectoPorId(Long Id){
        return proyectoRepository.findById(Id)
        .orElseThrow(()-> new RuntimeException("Proyecto no encontrado"));
    }


    public Proyecto saveProyecto (Proyecto nuevo){
        if (nuevo.getComentarios() == null || nuevo.getFecha() ==null || nuevo.getId_contrato() == null || nuevo.getId_estado() == null || nuevo.getId_proyecto() == null || nuevo.getId_tecnico() == null){
            throw new IllegalArgumentException("Todos los campos deben ser obligatorios");

        
        }
        return proyectoRepository.save(nuevo);
    }




}
