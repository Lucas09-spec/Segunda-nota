package com.resena.service;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.resena.model.Resena;
import com.resena.repository.ResenaRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional

public class ResenaService {
    @Autowired
    private ResenaRepository resenaRepository;
    
    public List<Resena> getResenas(){
        return resenaRepository.findAll();
        }

    public  Resena getResenaPorId (Long Id){
        return resenaRepository.findById(Id)
        .orElseThrow(()-> new RuntimeException("Reseña no encontrada"));


    }
    public Resena savResena (Resena nuevo){
        if (nuevo.getComentario() == null || nuevo.getF_com() == null || nuevo.getId_Reseña() == null || nuevo.getId_Usuario() == null || nuevo.getId_servicio() == null || nuevo.getNota() == null){
            throw new IllegalArgumentException("Todos los campos son obligatorios");

        }

        return resenaRepository.save(nuevo);
    }

    

}