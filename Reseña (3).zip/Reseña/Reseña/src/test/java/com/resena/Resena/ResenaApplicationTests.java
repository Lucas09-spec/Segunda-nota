package com.resena.Resena;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResenaApplicationTests {

	@Test
	void contextLoads() {
	}

}
